<pre><?php

print_r($GLOBALS);
print_r($_SERVER);
print_r($_REQUEST);
print_r($_POST);
print_r($_GET);
print_r($_FILES);
print_r($_ENV);
print_r($_COOKIE);
print_r($_SESSION);
?></pre>